import { Linkedin, Github, Mail, Phone, MessageCircle } from "lucide-react";
import { NAV_LINKS, FOUNDERS } from "@/data/siteData";

export function Footer() {
  return (
    <footer className="bg-ivory py-14">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-10 border-b border-ivory-border">
          <div className="md:col-span-4 space-y-4">
            <a href="#home" className="inline-flex items-center gap-3">
              <img
                src="/images/triqon-emblem.png"
                alt="TRIQON AI Logo"
                className="w-9 h-9 object-contain shrink-0"
              />
              <span className="font-display font-bold text-lg text-ink">
                TRIQON <span className="font-normal text-forest">AI</span>
              </span>
            </a>
            <p className="text-sm text-ink-secondary leading-relaxed max-w-sm">
              An emerging AI technology company building practical, accessible
              intelligent solutions for businesses and individuals.
            </p>
            <p className="text-xs font-mono uppercase tracking-[0.14em] text-terracotta">
              Intelligence. Innovation. Impact.
            </p>
          </div>

          <div className="md:col-span-3 space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-[0.14em] text-ink-muted">
              Navigation
            </h3>
            <ul className="grid grid-cols-2 gap-y-2 gap-x-4">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm text-ink-secondary hover:text-forest transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-5 space-y-3">
            <h3 className="text-xs font-mono uppercase tracking-[0.14em] text-ink-muted">
              Founders &amp; Direct Channels
            </h3>
            <ul className="space-y-2.5 text-sm text-ink-secondary">
              {FOUNDERS.map((founder) => (
                <li
                  key={founder.id}
                  className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-ivory-border/60 last:border-b-0 last:pb-0"
                >
                  <span className="font-medium text-ink">{founder.name}</span>
                  <div className="flex flex-wrap items-center gap-3 text-xs">
                    <a
                      href={founder.phoneHref}
                      className="inline-flex items-center gap-1 hover:text-forest transition-colors font-mono"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      {founder.phoneDisplay}
                    </a>
                    <a
                      href={founder.whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-forest hover:underline"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      WhatsApp
                    </a>
                    {founder.email && (
                      <a
                        href={`mailto:${founder.email}`}
                        aria-label={`${founder.name} Email`}
                        className="inline-flex items-center gap-1 hover:text-forest transition-colors"
                      >
                        <Mail className="w-3.5 h-3.5" />
                      </a>
                    )}
                    <a
                      href={founder.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`${founder.name} LinkedIn`}
                      className="inline-flex items-center gap-1 hover:text-forest transition-colors"
                    >
                      <Linkedin className="w-3.5 h-3.5" />
                    </a>
                    {founder.github && (
                      <a
                        href={founder.github}
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label={`${founder.name} GitHub`}
                        className="inline-flex items-center gap-1 hover:text-forest transition-colors"
                      >
                        <Github className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-ink-muted">
          <p>© {new Date().getFullYear()} TRIQON AI. All rights reserved.</p>
          <p className="font-mono">React + Vite · Ready for Vercel</p>
        </div>
      </div>
    </footer>
  );
}
